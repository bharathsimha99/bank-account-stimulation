class BankAccount {
    constructor() {
      this.isOpen = false;
      this.accountDetails = null;
    }
  
    openAccount(
      name,
      gender,
      dob,
      email,
      mobile,
      address,
      initialBalance,
      adharNo,
      panNo
    ) {
      if (this.isOpen) {
        console.log("Account is already open.");
        return;
      }
  
      this.accountDetails = {
        name,
        gender,
        dob,
        email,
        mobile,
        address,
        initialBalance,
        adharNo,
        panNo,
        balance: initialBalance,
        ledger: [],
      };
  
      this.isOpen = true;
      console.log("Account opened successfully.");
    }
  
    updateKYC(name, dob, email, mobile, adharNo, panNo) {
      if (!this.isOpen) {
        console.log("Account is not open.");
        return;
      }
  
      if (this.accountDetails) {
        this.accountDetails.name = name;
        this.accountDetails.dob = dob;
        this.accountDetails.email = email;
        this.accountDetails.mobile = mobile;
        this.accountDetails.adharNo = adharNo;
        this.accountDetails.panNo = panNo;
        console.log("KYC details updated successfully.");
      }
    }
  
    depositMoney(amount) {
      if (!this.isOpen) {
        console.log("Account is not open.");
        return;
      }
  
      if (this.accountDetails) {
        this.accountDetails.balance += amount;
        this.accountDetails.ledger.push(`Deposited $${amount}`);
        console.log(`$${amount} deposited successfully.`);
      }
    }
  
    withdrawMoney(amount) {
      if (!this.isOpen) {
        console.log("Account is not open.");
        return;
      }
  
      if (this.accountDetails) {
        if (this.accountDetails.balance >= amount) {
          this.accountDetails.balance -= amount;
          this.accountDetails.ledger.push(`Withdrawn $${amount}`);
          console.log(`$${amount} withdrawn successfully.`);
        } else {
          console.log("Insufficient balance.");
        }
      }
    }
  
    transferMoney(toName, amount) {
      if (!this.isOpen) {
        console.log("Account is not open.");
        return;
      }
  
      if (this.accountDetails) {
        if (this.accountDetails.balance >= amount) {
          this.accountDetails.balance -= amount;
          this.accountDetails.ledger.push(`Transferred $${amount} to ${toName}`);
          console.log(`$${amount} transferred to ${toName} successfully.`);
        } else {
          console.log("Insufficient balance.");
        }
      }
    }
  
    receiveMoney(fromName, amount) {
      if (!this.isOpen) {
        console.log("Account is not open.");
        return;
      }
  
      if (this.accountDetails) {
        this.accountDetails.balance += amount;
        this.accountDetails.ledger.push(`Received $${amount} from ${fromName}`);
        console.log(`$${amount} received from ${fromName} successfully.`);
      }
    }
  
    printStatement() {
      if (!this.isOpen) {
        console.log("Account is not open.");
        return;
      }
  
      if (this.accountDetails) {
        console.log("Account Details:");
        console.log(this.accountDetails);
        console.log("Transaction History:");
        console.log(this.accountDetails.ledger);
      }
    }
  
    closeAccount() {
      if (!this.isOpen) {
        console.log("Account is not open.");
        return;
      }
  
      this.accountDetails = null;
      this.isOpen = false;
      console.log("Account closed successfully.");
    }
  }
  
  // Example usage=>
  const myAccount = new BankAccount();
  myAccount.openAccount(
    "Bharathsimha",
    "Male",
    "21/08/2000",
    "singam@example.com",
    "98000010234",
    "Madgul,Rangareddy",
    1000,
    "123456789012",
    "ABCDE1234F"
  );
  myAccount.printStatement();
  myAccount.depositMoney(500);
  myAccount.withdrawMoney(200);
  myAccount.transferMoney("Charan", 300);
  myAccount.receiveMoney("Nithun", 100);
  myAccount.printStatement();
  myAccount.updateKYC(
    "Singam Bharathsimha.",
    "21/08/2000",
    "singambharath@example.com",
    "9876543210",
    "987654321098",
    "ZYXWV9876P"
  );
  //myAccount.printStatement();
  myAccount.closeAccount();
  